<html>
	<head>
	<META HTTP-EQUIV='Refresh' CONTENT='0; URL=Login_usuario/views/Registro.php'>	
            <title>
			Conexion PHP - ORACLE
		</title>
	</head>
	<body>
           
	<p>redireccion</p>	
		
	</body>
</html>