<?php
	$user = "system";
	$pass = "123";
	$db = "xe";
?>