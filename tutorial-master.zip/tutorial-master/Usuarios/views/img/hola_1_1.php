<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
        <link rel="stylesheet" href="Usuarios/views/css/bootstrap.css">
        <link rel="stylesheet" href="Usuarios/views/css/bootstrap.min.css">
        <link rel="stylesheet" href="Usuarios/views/css/bootstrap-responsive.min.css">
        <link rel="stylesheet" href="Usuarios/views/css/bootstrap-responsive.css">
         <script type="text/javascript">
            $(document).ready(function() {
                $("#dbody").css("position", "fixed");

                var altoNavegador = $(window).height() / 2;
                var altoSocial = $("#dbody").height() / 2;

                var topSocial = altoNavegador - altoSocial;
                $("#dbody").css("top", topSocial);
                $("#dbody").css("right", 0);
            });
        </script>
</head>
<style>
        body{
            background: url(Usuarios/views/img/fondo.jpg) repeat;
            background-size: 100% 900px;
            text-align: center;
        }
        #slogan{
            width: 300px;
            height: 400px;
            margin: 0px auto;
            background: url(Usuarios/views/img/Slogan.png) no-repeat;
            background-size: 300px 400px;
        }
            .Navbar {
  .Interior navbar-{
      background-image: ninguno;
    background-color: #003bb3;
/*    background-image: ninguno;*/
                   }
      }
      
      p{
        font-size: 40px;  
        color:  #f7f7f9;
        
      }
        
    </style>
<body>
    <div style=" float: right" ><a href="#"><img src="usuarios/views/img/f.png" alt="curso"  class="img-circle"></a></div>
    <div style=" float: right" ><a href="#"><img src="usuarios/views/img/t.png" alt="curso"  class="img-circle"></a></div>
    <div style=" float: right" ><a href="#"><img src="usuarios/views/img/g.png" alt="curso"  class="img-circle"></a></div>
    
    <div class=" container">
    <div id="slogan">

            </div>

            <div class="row-fluid">
            	<div class="span12">
            		<div class="page-header">
     
            		</div>

            		<div class="navbar ">
            			<div class="navbar-inner ">
                                    <a href="hola.php" class="brand">QuillaSport</a>
                                   <ul class="nav pull-center">
                                       <li class="divider-vertical"></li>
                                       <li class="active" ><a href="hola.php">Inicio</a></li>
                                  <li class="divider-vertical"></li>
                                  <li><a href="hola_1.php">galeria</a></li>
                                        <li class="divider-vertical"></li>
                                        <li><a href="hola_1_1.php">contactenos</a></li>
                                        <li class="divider-vertical"></li>
                                	<li><a href="#">noticias</a></li>
                                         <li class="divider-vertical"></li>
                                           <li><a href="#">Quienes somos</a></li>
                                         <li class="divider-vertical"></li>
                                        <li><a href="#">Barranquilla Deportes</a></li>
                                         <li class="divider-vertical"></li>
                                </ul>  
            			</div>
            		</div>
            	</div>
            </div>

        <div class="span12">
 <p class="text-muted">imagenes</p>
        </div>
<div class="row-fluid">
    
    
			<div class="span4">
                            <img src="usuarios/views/img/1.jpg" alt="curso"  class="img-rounded">
			</div>
                       <div class="span4">
                            <img src="usuarios/views/img/1.jpg" alt="curso"  class="img-circle">
                         </div>
			<div class="span4">
                            <img src="usuarios/views/img/1.jpg" alt="curso"  class="img-polaroid">
                        </div>
			
		</div>

		<div class="row">
			<div class="span12">
				 
				<h1>Cinegrama </h1>
					<p>
					Sofia Vergara tenía mucho que agradecer anoche en la celebración de Acción de Gracias. 
					Organizó una cena en la que su hijo Manolo ejerció de chef. Fotos: Facebook e Instagram 
					Sofia Vergar</p>
				
			</div>
		</div>


		<div class="row">
			
			<div class="span6">
			<h1>Cinegrama </h1>
					<p>
					Sofia Vergara tenía mucho que agradecer anoche en la celebración de Acción de Gracias. 
					Organizó una cena en la que su hijo Manolo ejerció de chef. Fotos: Facebook e Instagram 
					Sofia Vergar</p>
			</div>

			<div class="span6">
			 <h1>Cinegrama </h1>
					<p>
					Sofia Vergara tenía mucho que agradecer anoche en la celebración de Acción de Gracias. 
					Organizó una cena en la que su hijo Manolo ejerció de chef. Fotos: Facebook e Instagram 
					Sofia Vergar</p>
			</div>
		

		</div>

	</div>
	
</body>
</html>